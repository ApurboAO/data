#include <bits/stdc++.h>
#include "2105057_1_ll_queue.cpp"
// #include"2105057_1_a_queue.cpp"

int main()
{

    Queue<int> a, b, c;

    string input;
    while (getline(cin, input))
    {
        string one, two;
        cin >> one >> two;
        if (one == "terminate")
        {
            return;
        }
        else if (one == "enter")
        {
            if (b.length() > c.length())
            {
                c.enqueue(stoi(two));
                cout<<"Customer "<<stoi(two)<<"  enters queue B"<<endl;
            }
            else if (b.length() > c.length())
            {
                b.enqueue(stoi(two));
                cout<<"Customer "<<stoi(two)<<"  enters queue C"<<endl;
            }
            else
            {
                b.enqueue(stoi(two));
                cout<<"Customer "<<stoi(two)<<"  enters queue B"<<endl;
            }
        }
        else
        {
            if (one == "B")
            {
                if (two == "approve")
                {
                    a.enqueue(b.front());
                    cout<<"Customer "<<b.front()<<"  enters queue A"<<endl;
                }
                else
                {
                    int rejected = b.front();
                    b.dequeue();
                    if (b.length() < c.length())
                    {
                        c.enqueue(rejected);
                        cout<<"Customer "<<b.front()<<"  enters queue C"<<endl;
                    }
                    else if (b.length() > c.length())
                    {
                        b.enqueue(rejected);
                        cout<<"Customer "<<b.front()<<"  enters queue B"<<endl;
                    }
                    else
                    {
                        b.enqueue(rejected);
                        cout<<"Customer "<<b.front()<<"  enters queue B"<<endl;
                    }
                }
            }
            else if (one == "C")
            {
                if (two == "approve")
                {
                    a.enqueue(c.front());
                     cout<<"Customer "<<c.front()<<"  enters queue A"<<endl;
                }
                else
                {
                    int rejected = c.front();
                    b.dequeue();
                    if (b.length() < c.length())
                    {
                        c.enqueue(rejected);
                         cout<<"Customer "<<c.front()<<"  enters queue C"<<endl;
                    }
                    else if (b.length() > c.length())
                    {
                        b.enqueue(rejected);
                         cout<<"Customer "<<c.front()<<"  enters queue B"<<endl;
                    }
                    else
                    {
                        b.enqueue(rejected);
                         cout<<"Customer "<<c.front()<<"  enters queue B"<<endl;
                    }
                }
            }
            else
            {
               if (two == "approve")
                {
                    cout<<"Customer"<<a.front()<<"gets the loan"<<endl;
                    a.dequeue();
                } 
            }
        }
    }

    return 0;
}